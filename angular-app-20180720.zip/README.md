# angular-app
 - angular-cli+cmui+html5+css3+typescript+tslint
 - 适合开发各种webapp、企业网站、后台管理系统等等任何系统
 - cmui仓库为https://github.com/womendi/cmui.git
 - 结合hbuilder打包，可以直接做成全平台应用。例如 亲信地铁（vueapp） 腾讯应用宝或苹果appstore搜索‘亲信地铁’、web访问http://m.aiplat.com/metro
 
 - 代码实例：      ai智能空间angular版 http://ajs.aiplat.com
 - 实例相对应网站1：ai智能空间vue版     http://www.aiplat.com 
 - 实例相对应网站2：ai智能空间react版   http://react.aiplat.com 
 - 实例相对应网站3：ai智能空间nervjs版  http://nerv.aiplat.com 

## 待完善..