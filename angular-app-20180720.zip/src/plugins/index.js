//全局配置
window.site = { name: 'react-app-ie8', webapp: true, logo: require('assets/images/icon.png'), description: 'react+redux+react-router+cmui+html5+css3+less+es6+webpack+兼容IE8,适合开发各种webapp、企业网站、后台管理系统等等任何系统', site: 'aiplat.com', url: 'http://aiplat.com' }

//全局cmapp
window.cm = require('./cmapp');

//全局cookie
//window.coki = require('./cookie');

// import FastClick from 'fastclick'
// FastClick.attach(document.body)

export default window;