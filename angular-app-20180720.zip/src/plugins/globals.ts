import {Injectable} from '@angular/core'

Injectable()

export class Globals{
    site={ name: 'angular-app', webapp: true, logo: 'assets/images/icon.png', description: 'angular-cli+cmui+html5+css3+typescript+tslint,适合开发各种webapp、企业网站、后台管理系统等等任何系统', site: 'aiplat.com', url: 'http://aiplat.com' }
}