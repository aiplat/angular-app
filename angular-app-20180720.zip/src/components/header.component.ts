import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html'
})
export class Header {
  @Input('headData') headData: any;
  images = { imgL: 'assets/images/commons/cm_back2.png' };
  constructor() {
    document.title = 'angular-app';
  }
  toBack():void{
    window.history.go(-1);
  }
}

/*

引用组件

*.ts

import { Component,ViewChild } from '@angular/core';

import {Header} from '../../components/header.component'


@ViewChild('header')
  header:Header;
  headData = {title:'404',isImgL:true};

*.html

<app-header [headData]='headData'></app-header>

  */
